PopulationSim
=============

PopulationSim is an open platform for population synthesis.  It emerged
from Oregon DOT's desire to build a shared, open, platform that could be 
easily adapted for statewide, regional, and urban transporation planning 
needs.  PopulationSim is implemented in the 
[ActivitySim](https://github.com/activitysim/activitysim) framework. 
