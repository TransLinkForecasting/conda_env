
## Scripts

  - validationPopulationSim.R - R validation script to generate advanced summary statistics and validation plots. This validation script takes summaries and outputs from a PopulationSim run. The script is configured to run for the CALM region example and includes notes on inputs and configuration settings
  - columnMapPopSim_CALM.csv - CSV file to specify the controls for which the summaries should be generated