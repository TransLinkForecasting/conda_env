
## Scripts

  - validation.ipynb - Jupyter validation script to generate advanced summary statistics and validation plots. This validation script takes summaries and outputs from a PopulationSim run. The script is configured to run for the CALM region example and includes notes on inputs and configuration settings
  - calm_verification.yaml - YAML file to specify the controls for which the summaries should be generated
