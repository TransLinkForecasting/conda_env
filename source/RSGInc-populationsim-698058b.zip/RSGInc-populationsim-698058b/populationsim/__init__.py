# PopulationSim
# See full license in LICENSE.txt.

__version__ = version = '0.1dev'
